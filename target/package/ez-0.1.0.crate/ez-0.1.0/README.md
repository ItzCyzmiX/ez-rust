# ez-rust
ez yo use utility functions for rust
